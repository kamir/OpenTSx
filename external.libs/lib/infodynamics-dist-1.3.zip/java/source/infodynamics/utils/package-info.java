/**
 * This package contains utility classes to
 * support the calculators in other packages
 * 
 * @author Joseph Lizier (<a href="joseph.lizier at gmail.com">email</a>,
 * <a href="http://lizier.me/joseph/">www</a>)
 */
package infodynamics.utils;
