The classes under the JIDT package infodynamics.utils.commonsmath3 were
originally distributed as part of the Apache Commons
Math3 library, under the Apache License V2.0 (see ApacheCommons-LICENSE.txt).
This Apache 2 software is now included as a derivative
work in the GPLv3 licensed JIDT project, as per:
http://www.apache.org/licenses/GPL-compatibility.html
 
The original Apache source code has been modified as follows:
 -- We have modified package names to sit inside the JIDT structure.

As required by the license, we have:
1. Given a copy of the original Apache License V2.0 in ApacheCommons-LICENSE.txt
2. We have noted how the original classes have been modified in their 
    header comments.
3. We have kept the original notices in the headers of each class.
4. We included the original notice file as ApacheCommons-NOTICE.txt

Note that the original license and notice files contain text referring to
derived code that is not redistributed in JIDT.
