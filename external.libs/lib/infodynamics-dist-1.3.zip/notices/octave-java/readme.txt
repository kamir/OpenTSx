octave-java package of the Octave-Forge project -- http://octave.sourceforge.net/java/

This project is distributed under GPLv3 also; see the license file in the top level of this distribution.

The code in infodynamics.utils.OctaveMatrix was adapted from this source.


